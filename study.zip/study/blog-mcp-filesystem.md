# 用 MCP 让 AI 真正操作你的文件系统：从概念到实战

> **目标读者：** 有 Python 基础、了解 API 调用的中级开发者
> **阅读时间：** 约 15 分钟
> **收获：** 理解 MCP 协议原理，并能从零搭建文件系统 MCP Server

---

## 第 1 章：什么是 MCP？

你有没有遇到过这样的困境：想让 AI 帮你处理本地文件，却发现它只能"看"不能"动"？想让它查数据库、调用内部 API，却每次都要写一堆胶水代码？

这就是 **MCP（Model Context Protocol）** 要解决的问题。

### MCP 是什么？

MCP 全称 **Model Context Protocol**，是 Anthropic 于 2024 年底发布的开放协议。它的目标很简单：**为 AI 模型与外部工具/数据源的集成，定义一套标准化的通信接口**。

官方定义一句话概括：

> MCP is an open protocol that standardizes how applications provide context to LLMs.

用一个类比来理解：**MCP 就是 AI 世界的 USB-C 接口**。不管是 Claude、GPT 还是其他模型，只要支持 MCP，就能即插即用地接入任何实现了 MCP 协议的工具或数据服务。

### MCP vs Function Calling：有什么本质区别？

很多开发者第一反应是：这不就是 Function Calling 吗？确实，两者都是让 AI "调用工具"，但设计哲学截然不同：

| 维度 | Function Calling | MCP |
|------|-----------------|-----|
| 工具定义位置 | 嵌入在 API 请求体中 | 独立的 Server 进程 |
| 工具实现者 | 调用方（你的应用） | Server 开发者（可复用） |
| 跨模型复用 | 不能（强绑定 API 格式） | 可以（标准协议） |
| 部署方式 | 无独立进程 | 独立运行的服务 |
| 典型场景 | 单应用集成 | 工具生态共享 |

**Function Calling** 更像是：你每次开车都要自己临时焊一个方向盘。
**MCP** 更像是：方向盘有了标准接口，任何车直接插上就能用。

理解了这个区别，我们来看 MCP 的内部结构。

---

## 第 2 章：MCP 核心概念

MCP 的架构由两个核心角色组成：**Client（客户端）** 和 **Server（服务端）**。

```
┌─────────────┐    MCP Protocol    ┌─────────────┐
│  MCP Client │◄──────────────────►│  MCP Server │
│  (Claude)   │                    │  (你的程序)  │
└─────────────┘                    └──────┬──────┘
                                          │
                              ┌───────────┼───────────┐
                           Tools      Resources    Prompts
                         (可执行操作) (可读数据)  (预设提示词)
```

- **MCP Client**：发起请求的一方，通常是 AI 模型的宿主环境，例如 Claude Desktop、Claude Code CLI 等。
- **MCP Server**：响应请求的一方，就是**你要编写的程序**，负责暴露工具和数据。

### Server 能暴露三类能力

**1. Tools（工具）——本文重点**

Tools 是 AI 可以"调用"的函数，类似 Function Calling 中的函数定义。区别在于，Tool 定义在 Server 侧，AI 通过 MCP 协议发现并调用它们。

文件系统操作（列目录、读文件、写文件）就是典型的 Tool。

**2. Resources（资源）**

Resources 是 AI 可以"读取"的数据源，例如某个文件的实时内容、数据库查询结果、API 返回数据等。Resources 是"只读"的数据暴露，而不是可执行的操作。

**3. Prompts（提示词模板）**

Prompts 是预定义的提示词模板，Server 可以将复杂的指令封装成模板，Client 可以直接引用。这对于需要标准化提示的场景非常有用。

本文聚焦在 **Tools** 上，这也是最常用、最直接的能力。

---

## 第 3 章：MCP 工作流程

了解概念之后，我们来看 MCP 通信的完整流程。

### 通信协议

MCP 底层使用 **JSON-RPC 2.0** 作为消息格式，传输层支持两种方式：

- **stdio**：通过标准输入/输出通信，适合本地运行的 Server（本文使用这种方式）
- **HTTP + SSE**：通过 HTTP 和 Server-Sent Events 通信，适合远程部署

### 完整交互流程

```
1. 启动阶段
   Client 启动 Server 进程
   → Client 发送 initialize 请求
   → Server 返回能力声明（支持哪些 Tools/Resources/Prompts）

2. 工具发现
   Client → Server: tools/list
   Server → Client: [list_directory, read_file, write_file, ...]

3. AI 决策
   用户提问："帮我列出 /home/user/projects 下的文件"
   Claude 分析问题，决定调用 list_directory 工具

4. 工具调用
   Client → Server: tools/call
   {
     "name": "list_directory",
     "arguments": {"path": "/home/user/projects"}
   }

5. 返回结果
   Server 执行操作，返回结果
   Server → Client: "[目录] backend\n[文件] README.md\n..."
   Claude 将结果整合成自然语言回复给用户
```

一个实际的 JSON-RPC 调用请求长这样：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "list_directory",
    "arguments": {
      "path": "/home/user/projects"
    }
  }
}
```

Server 返回：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "[目录] backend\n[目录] frontend\n[文件] README.md"
      }
    ]
  }
}
```

这套流程完全标准化，这就是 MCP 的核心价值——**你写一次 Server，任何支持 MCP 的 AI 客户端都能用**。

---

## 第 4 章：环境搭建

理论讲完，开始动手。

### 环境要求

- **Python 3.10+**（MCP SDK 使用了较新的类型语法）
- pip 包管理器

### 安装 MCP SDK

```bash
pip install mcp
```

就这一行，MCP 的 Python SDK 会自动安装所有依赖。

### 项目结构

```
my-mcp-project/
├── filesystem_server.py    # MCP Server 主文件
└── README.md               # 可选
```

本文的示例非常简洁，只需要一个文件。

---

## 第 5 章：实战——文件系统 MCP Server

这是本文的核心章节。我们将实现一个支持**列目录、读文件、写文件**三个操作的 MCP Server。

### 完整代码

```python
import asyncio
from pathlib import Path
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

# 初始化 MCP Server，指定名称
app = Server("filesystem-server")


@app.list_tools()
async def list_tools() -> list[types.Tool]:
    """声明本 Server 提供哪些工具，Client 连接时会调用此函数"""
    return [
        types.Tool(
            name="list_directory",
            description="列出指定目录下的文件和文件夹",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "目录路径"}
                },
                "required": ["path"]
            }
        ),
        types.Tool(
            name="read_file",
            description="读取指定文件的内容",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "文件路径"}
                },
                "required": ["path"]
            }
        ),
        types.Tool(
            name="write_file",
            description="将内容写入指定文件",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "文件路径"},
                    "content": {"type": "string", "description": "要写入的内容"}
                },
                "required": ["path", "content"]
            }
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    """处理工具调用请求，根据 name 分发到对应处理逻辑"""

    if name == "list_directory":
        path = Path(arguments["path"])
        if not path.is_dir():
            return [types.TextContent(type="text", text=f"错误：{path} 不是有效目录")]
        items = [
            f"{'[目录]' if p.is_dir() else '[文件]'} {p.name}"
            for p in path.iterdir()
        ]
        return [types.TextContent(type="text", text="\n".join(items) or "目录为空")]

    elif name == "read_file":
        path = Path(arguments["path"])
        if not path.is_file():
            return [types.TextContent(type="text", text=f"错误：{path} 不存在")]
        return [types.TextContent(type="text", text=path.read_text(encoding="utf-8"))]

    elif name == "write_file":
        path = Path(arguments["path"])
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(arguments["content"], encoding="utf-8")
        return [types.TextContent(type="text", text=f"已成功写入 {path}")]

    else:
        return [types.TextContent(type="text", text=f"未知工具：{name}")]


async def main():
    """通过 stdio 启动 MCP Server"""
    async with stdio_server() as streams:
        await app.run(*streams, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
```

### 代码解析

**`Server("filesystem-server")`**
创建一个 MCP Server 实例，名称用于 Client 识别。

**`@app.list_tools()`**
装饰器注册"工具列表"处理函数。当 Client 调用 `tools/list` 时，MCP SDK 自动调用这个函数。每个 `types.Tool` 描述一个工具的名称、用途和参数 Schema（JSON Schema 格式）。

**`inputSchema`**
这是 AI 理解工具的关键。`description` 字段直接影响 AI 的决策——写得清晰，AI 就能准确选择工具；写得模糊，AI 可能用错工具或不知道何时调用。

**`@app.call_tool()`**
装饰器注册"工具调用"处理函数。当 AI 决定调用某个工具时，SDK 会把 `name` 和 `arguments` 传入这个函数。返回值是 `TextContent` 列表，即工具执行结果。

**`stdio_server()`**
使用 stdio 模式运行，Server 通过标准输入/输出与 Client 通信。这是本地部署最简单的方式，不需要配置端口或网络。

### 验证 Server 能运行

```bash
python filesystem_server.py
```

运行后终端会进入等待状态（等待 stdio 输入），这说明 Server 已正常启动。按 `Ctrl+C` 退出。

---

## 第 6 章：接入 Claude Code CLI

Server 写好了，现在让它和 Claude Code 对话。

### 注册 MCP Server

**方法一：通过命令行添加（推荐）**

```bash
claude mcp add filesystem python /path/to/filesystem_server.py
```

将 `/path/to/filesystem_server.py` 替换为你的实际文件路径，例如：

```bash
# macOS/Linux
claude mcp add filesystem python /home/user/my-mcp-project/filesystem_server.py

# Windows
claude mcp add filesystem python C:\Users\user\my-mcp-project\filesystem_server.py
```

**方法二：手动编辑配置文件**

找到 Claude Code 的配置文件（位于 `~/.claude/settings.json`），添加如下配置：

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "python",
      "args": ["/path/to/filesystem_server.py"]
    }
  }
}
```

### 验证注册成功

```bash
claude mcp list
```

如果看到如下输出，说明注册成功：

```
filesystem: python /path/to/filesystem_server.py
```

### 实际使用演示

启动 Claude Code 对话：

```bash
claude
```

然后直接用自然语言提问：

```
> 请列出 /home/user/projects 目录下的所有文件和文件夹

Claude 的内部处理过程：
1. 分析用户意图：需要列出目录内容
2. 发现可用工具：list_directory（来自 filesystem MCP Server）
3. 决定调用：list_directory(path="/home/user/projects")
4. 接收 Server 返回：[目录] backend\n[文件] README.md\n...
5. 整合回复：为用户呈现格式化的目录内容

Claude 的回复：
"/home/user/projects 目录下共有以下内容：
- [目录] backend
- [目录] frontend
- [文件] README.md
- [文件] docker-compose.yml"
```

你也可以链式操作：

```
> 读取 /home/user/projects/README.md 的内容，然后帮我把摘要写入 /tmp/summary.txt
```

Claude 会自动依次调用 `read_file` 和 `write_file`，完成这个多步骤任务。

---

## 第 7 章：常见问题与扩展思路

### 常见踩坑

**1. 路径权限问题**

MCP Server 以 Python 进程的权限运行。如果遇到 `PermissionError`，检查：
- 目标路径是否存在
- 当前用户是否有读写权限
- Linux/macOS 上注意 `sudo` 权限问题

**2. Windows 路径分隔符**

Windows 使用反斜杠 `\`，但在 JSON 中需要转义为 `\\`，或者直接使用正斜杠 `/`（Python 的 `pathlib` 都能处理）：

```python
# 推荐：使用 pathlib，自动处理跨平台路径
path = Path(arguments["path"])  # 兼容 Windows 和 Unix
```

**3. 编码问题**

读写文件时务必指定编码，尤其是在 Windows 环境：

```python
# 始终显式指定 encoding
path.read_text(encoding="utf-8")
path.write_text(content, encoding="utf-8")
```

**4. Server 进程崩溃无日志**

stdio 模式下，`print()` 输出会干扰 MCP 通信。调试时使用 `stderr`：

```python
import sys
print("调试信息", file=sys.stderr)
```

### 安全注意事项：防止目录遍历攻击

当前实现没有路径限制，这意味着 AI（或者恶意提示词注入）可能读取任意文件，例如 `/etc/passwd`。

生产环境中，务必添加路径白名单限制：

```python
ALLOWED_BASE_DIR = Path("/home/user/projects")  # 只允许操作这个目录

def validate_path(path: Path) -> bool:
    """确保路径在允许的目录范围内"""
    try:
        path.resolve().relative_to(ALLOWED_BASE_DIR.resolve())
        return True
    except ValueError:
        return False

# 在每个工具调用前验证
if not validate_path(path):
    return [types.TextContent(type="text", text="错误：不允许访问该路径")]
```

### 扩展思路

掌握了文件系统 MCP Server 的基本结构，你可以快速扩展：

**添加更多文件工具：**
- `delete_file`：删除文件（注意安全确认）
- `rename_file`：重命名或移动文件
- `search_files`：按内容或文件名搜索
- `get_file_info`：获取文件元数据（大小、修改时间等）

**接入数据库：**
将 `sqlite3` 或 `psycopg2` 封装成工具，让 AI 直接查询数据库。

**部署为 HTTP Server：**

如果需要远程访问，将 stdio 改为 HTTP 模式：

```python
from mcp.server.sse import SseServerTransport
# 使用 SSE 传输替代 stdio，支持远程连接
```

**与其他 MCP Server 组合：**

MCP 的生态正在快速成长。你可以同时注册多个 MCP Server——文件系统 Server + 数据库 Server + 邮件 Server，让 AI 在一次对话中跨工具协作完成复杂任务。

---

## 总结

本文从概念到实战，带你完整走了一遍 MCP 的核心路径：

| 步骤 | 内容 |
|------|------|
| 理解 MCP | 标准化 AI 工具集成协议，区别于 Function Calling |
| 掌握架构 | Client/Server 模型，Tools/Resources/Prompts 三类能力 |
| 理解流程 | JSON-RPC 2.0 通信，工具发现→决策→调用→返回 |
| 搭建 Server | `pip install mcp`，实现 `list_tools` 和 `call_tool` |
| 接入 Claude | `claude mcp add` 注册，自然语言驱动文件操作 |

MCP 的真正价值不只是让 AI 操作文件——它代表的是一种**工具即服务**的思维：把你的业务能力标准化为 MCP Server，任何支持 MCP 的 AI 都能即插即用。

现在，你已经拥有了构建自己 MCP Server 的完整知识。下一步，去把你的业务逻辑封装进去吧。

---

## 参考资源

- [MCP 官方文档](https://modelcontextprotocol.io)
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [Claude Code CLI 文档](https://docs.anthropic.com/claude-code)
- [MCP Server 示例集合](https://github.com/modelcontextprotocol/servers)
