# 双色球智能选号网页 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 创建单文件网页 `index.html`，以当前时间戳为随机数种子自动生成双色球号码，支持手动触发重新选号并以落球动画逐个展示结果。

**Architecture:** 纯 HTML + CSS + 原生 JS 单文件。LCG 伪随机算法（带 `>>> 0` 无符号保证）+ Fisher-Yates 洗牌生成号码；CSS `@keyframes drop-in` 动画控制球逐个落入；`animationend { once: true }` 监听第7球完成后恢复按钮。

**Tech Stack:** HTML5, CSS3 (keyframe animation, radial-gradient), Vanilla JavaScript (ES6+)

---

## 文件结构

| 文件 | 职责 |
|------|------|
| `index.html` | 唯一文件：页面结构、样式、随机算法、动画逻辑全部内联 |

---

### Task 1: 页面骨架与静态样式

**Files:**
- Create: `index.html`

- [ ] **Step 1: 创建 HTML 骨架**

创建 `index.html`，内容如下（仅结构，无动画逻辑）：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>双色球智能选号</title>
  <style>
    /* 占位，Task 2 填充 */
  </style>
</head>
<body>
  <div class="card">
    <h1>双色球智能选号</h1>
    <p class="subtitle">以时间为种子</p>

    <div class="balls-row">
      <!-- 红球区 -->
      <div class="red-zone" id="redZone">
        <!-- 由 JS 动态插入 -->
      </div>
      <!-- 分隔线 -->
      <div class="divider"></div>
      <!-- 蓝球区 -->
      <div class="blue-zone" id="blueZone">
        <!-- 由 JS 动态插入 -->
      </div>
    </div>

    <div class="seed-info" id="seedInfo">
      <!-- 由 JS 填充 -->
    </div>

    <button id="btn" onclick="generate()">开始摇号</button>
  </div>

  <script>
    /* 占位，Task 3 填充 */
  </script>
</body>
</html>
```

- [ ] **Step 2: 在浏览器中打开文件，确认骨架渲染正常**

用浏览器打开 `index.html`，预期：页面显示标题"双色球智能选号"和按钮"开始摇号"，无报错。

---

### Task 2: 样式系统（球、动画、布局）

**Files:**
- Modify: `index.html` — 填充 `<style>` 标签

- [ ] **Step 1: 写入完整 CSS**

将 `<style>` 内容替换为：

```css
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f0f2f5;
  font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
}

.card {
  background: #fff;
  border-radius: 16px;
  padding: 40px 48px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.10);
  text-align: center;
  min-width: 480px;
}

h1 {
  font-size: 28px;
  color: #c0392b;
  letter-spacing: 2px;
  margin-bottom: 4px;
}

.subtitle {
  font-size: 13px;
  color: #999;
  margin-bottom: 32px;
}

/* 球行布局 */
.balls-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0;
  margin-bottom: 24px;
  min-height: 72px;
}

.red-zone {
  display: flex;
  gap: 10px;
}

.blue-zone {
  display: flex;
}

.divider {
  width: 2px;
  height: 60px;
  background: #e0e0e0;
  margin: 0 16px;
  border-radius: 1px;
}

/* 球基础样式 */
.ball {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  font-weight: 700;
  color: #fff;
  text-shadow: 0 1px 2px rgba(0,0,0,0.3);
  box-shadow:
    inset -4px -4px 8px rgba(0,0,0,0.25),
    inset 4px 4px 8px rgba(255,255,255,0.35),
    0 4px 12px rgba(0,0,0,0.20);
  opacity: 0;
  /* 动画默认不播放 */
}

.ball.red {
  background: radial-gradient(circle at 35% 35%, #ff6b6b, #c0392b 60%, #922b21);
}

.ball.blue {
  background: radial-gradient(circle at 35% 35%, #74b9ff, #2980b9 60%, #1a5276);
}

/* 落球动画 */
@keyframes drop-in {
  0%   { opacity: 0; transform: translateY(-80px) scale(0.6); }
  60%  { opacity: 1; transform: translateY(10px) scale(1.05); }
  80%  { transform: translateY(-6px) scale(0.97); }
  95%  { transform: translateY(3px) scale(1.01); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}

.ball.animate {
  animation: drop-in 0.4s cubic-bezier(0.22, 1, 0.36, 1) forwards;
}

/* 种子信息 */
.seed-info {
  font-size: 13px;
  color: #aaa;
  margin-bottom: 28px;
  min-height: 36px;
  line-height: 1.6;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.seed-info.visible {
  opacity: 1;
}

/* 按钮 */
#btn {
  background: linear-gradient(135deg, #e74c3c, #c0392b);
  color: #fff;
  border: none;
  border-radius: 50px;
  padding: 14px 48px;
  font-size: 18px;
  font-weight: 600;
  letter-spacing: 2px;
  cursor: pointer;
  box-shadow: 0 4px 16px rgba(192,57,43,0.4);
  transition: transform 0.1s, box-shadow 0.1s, background 0.2s;
}

#btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(192,57,43,0.5);
}

#btn:active:not(:disabled) {
  transform: translateY(0);
}

#btn:disabled {
  background: linear-gradient(135deg, #bbb, #999);
  box-shadow: none;
  cursor: not-allowed;
}
```

- [ ] **Step 2: 在浏览器中验证样式**

刷新 `index.html`，预期：白色卡片居中，标题红色，按钮红色圆角，无球（JS未写）。控制台无报错。

---

### Task 3: 随机算法与号码生成

**Files:**
- Modify: `index.html` — 填充 `<script>` 标签

- [ ] **Step 1: 写入 LCG 算法与号码生成函数**

将 `<script>` 内容替换为：

```js
let clickCount = 0;

// 初始化种子：Date.now() + 加法 nonce，防止快速点击种子重复
function initSeed() {
  return Date.now() + clickCount++;
}

// LCG 伪随机数生成器：返回 [新seed, 浮点数∈[0,1)]
function next(seed) {
  seed = ((seed * 1664525 + 1013904223) & 0xFFFFFFFF) >>> 0;
  return [seed, seed / 0x100000000];
}

// 生成双色球号码：6个红球(1-33不重复升序) + 1个蓝球(1-16)
function generateNumbers(seed) {
  // 红球：Fisher-Yates 洗牌 [1..33]，取前6个
  const arr = Array.from({ length: 33 }, (_, i) => i + 1);
  let r;
  for (let i = 32; i >= 1; i--) {
    [seed, r] = next(seed);
    const j = Math.floor(r * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  const red = arr.slice(0, 6).sort((a, b) => a - b);

  // 蓝球：1-16
  [seed, r] = next(seed);
  const blue = Math.floor(r * 16) + 1;

  return { red, blue };
}
```

- [ ] **Step 2: 在浏览器控制台验证算法正确性**

打开浏览器开发者工具，执行以下验证命令：

```js
// 验证1：同一种子产生相同结果
const s = 1711700000000;
const r1 = generateNumbers(s);
const r2 = generateNumbers(s);
console.assert(JSON.stringify(r1) === JSON.stringify(r2), '可复现性失败');

// 验证2：红球规则
console.assert(r1.red.length === 6, '红球数量不对');
console.assert(r1.red.every(n => n >= 1 && n <= 33), '红球范围错误');
const unique = new Set(r1.red);
console.assert(unique.size === 6, '红球有重复');
// 验证升序
for (let i = 1; i < r1.red.length; i++) {
  console.assert(r1.red[i] > r1.red[i-1], '红球未升序');
}

// 验证3：蓝球规则
console.assert(r1.blue >= 1 && r1.blue <= 16, '蓝球范围错误');

console.log('所有验证通过', r1);
```

预期：控制台输出"所有验证通过"及一组号码，无断言错误。

---

### Task 4: 动画渲染与交互逻辑

**Files:**
- Modify: `index.html` — 在 `<script>` 中追加 `generate()` 函数及初始化调用

- [ ] **Step 1: 追加 `generate()` 函数及页面初始化**

在 `</script>` 前追加：

```js
// 格式化时间戳为可读字符串
function formatTime(ts) {
  const d = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ` +
         `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.` +
         String(d.getMilliseconds()).padStart(3, '0');
}

function generate() {
  const btn = document.getElementById('btn');
  const redZone = document.getElementById('redZone');
  const blueZone = document.getElementById('blueZone');
  const seedInfo = document.getElementById('seedInfo');

  // 1. 记录种子（同一变量用于显示和生成）
  const seed = initSeed();
  const ts = seed - (clickCount - 1); // 还原原始 Date.now() 用于显示
  // 注意：seed = Date.now() + clickCount-1，显示原始时间戳更直观
  // 实际显示种子本身（含nonce）更准确，用 seed 展示
  seedInfo.innerHTML =
    `时间种子：${seed}<br>（${formatTime(ts)}）`;
  seedInfo.classList.add('visible');

  // 2. 禁用按钮
  btn.disabled = true;

  // 3. 生成号码
  const { red, blue } = generateNumbers(seed);

  // 4. 清空旧球（淡出由 CSS opacity:0 初始值保证新球重建即隐藏）
  redZone.innerHTML = '';
  blueZone.innerHTML = '';

  // 5. 逐球创建并延迟添加 animate 类（触发 drop-in 动画）
  const allBalls = [];

  red.forEach((num, i) => {
    const ball = document.createElement('div');
    ball.className = 'ball red';
    ball.textContent = String(num).padStart(2, '0');
    ball.style.animationDelay = `${i * 200}ms`;
    redZone.appendChild(ball);
    allBalls.push(ball);
  });

  const blueBall = document.createElement('div');
  blueBall.className = 'ball blue';
  blueBall.textContent = String(blue).padStart(2, '0');
  blueBall.style.animationDelay = `${6 * 200}ms`;
  blueZone.appendChild(blueBall);
  allBalls.push(blueBall);

  // 6. 触发动画（requestAnimationFrame 确保 DOM 已渲染）
  requestAnimationFrame(() => {
    allBalls.forEach(ball => ball.classList.add('animate'));
  });

  // 7. 第7球动画结束后恢复按钮
  blueBall.addEventListener('animationend', () => {
    btn.disabled = false;
  }, { once: true });
}

// 页面加载时自动生成一次
generate();
```

- [ ] **Step 2: 在浏览器中验证完整交互**

刷新 `index.html`，逐项检查：

| 检查项 | 预期结果 |
|--------|---------|
| 页面加载 | 自动触发一次摇号，7个球依次落入 |
| 球的样式 | 6个红球 + 竖线分隔 + 1个蓝球，3D光泽渐变 |
| 动画节奏 | 红球间隔约200ms，蓝球最后落入，每球弹跳停稳 |
| 种子信息 | 数字时间戳 + 格式化时间字符串，动画开始时立即显示 |
| 按钮状态 | 动画期间变灰不可点击，蓝球落完后恢复红色 |
| 再次点击 | 新号码正常生成，种子更新 |
| 快速连续点击 | 按钮在动画期间已禁用，不会触发并发生成 |

- [ ] **Step 3: 控制台无错误确认**

打开开发者工具 Console，确认无红色报错。

---

### Task 5: 最终检查与收尾

**Files:**
- Modify: `index.html` — 修复任何发现的问题（如有）

- [ ] **Step 1: 跨浏览器基本检查**

在以下任意一种浏览器中打开并验证功能正常：Chrome / Edge / Firefox

- [ ] **Step 2: 对照规格文档做最终核查**

| 规格要求 | 是否满足 |
|---------|---------|
| 6个红球，范围1-33，不重复，升序 | ☐ |
| 1个蓝球，范围1-16 | ☐ |
| 同一种子产生相同号码（可在控制台验证） | ☐ |
| 页面加载自动生成 | ☐ |
| 按钮手动触发重新生成 | ☐ |
| 球从上方落入并弹跳 | ☐ |
| 种子信息立即显示（含时间戳和格式化时间） | ☐ |
| 按钮动画期间禁用 | ☐ |
| 零外部依赖，单文件 | ☐ |

- [ ] **Step 3: 完成**

`index.html` 即为最终交付物，直接浏览器打开即用。
