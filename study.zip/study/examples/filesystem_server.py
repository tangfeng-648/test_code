"""
文件系统 MCP Server 示例
========================

这是《用 MCP 让 AI 真正操作你的文件系统：从概念到实战》配套代码。

功能：
- list_directory：列出指定目录下的文件和文件夹
- read_file：读取指定文件的内容
- write_file：将内容写入指定文件

环境要求：
- Python 3.10+
- mcp 包（pip install mcp）

运行方式：
  python filesystem_server.py

接入 Claude Code：
  claude mcp add filesystem python /path/to/filesystem_server.py
"""

import asyncio
from pathlib import Path
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

# ─── 安全配置（可选）────────────────────────────────────────────────────────────
# 取消注释并设置 ALLOWED_BASE_DIR 以限制可操作的目录范围，防止目录遍历攻击
# ALLOWED_BASE_DIR = Path("/home/user/projects")

# def validate_path(path: Path) -> bool:
#     """确保路径在允许的目录范围内"""
#     try:
#         path.resolve().relative_to(ALLOWED_BASE_DIR.resolve())
#         return True
#     except ValueError:
#         return False
# ─────────────────────────────────────────────────────────────────────────────

# 初始化 MCP Server，名称用于 Client 识别
app = Server("filesystem-server")


@app.list_tools()
async def list_tools() -> list[types.Tool]:
    """
    声明本 Server 提供哪些工具。
    Client 建立连接时会调用 tools/list，SDK 自动路由到此函数。
    每个 Tool 的 description 和 inputSchema 直接影响 AI 的工具选择决策。
    """
    return [
        types.Tool(
            name="list_directory",
            description="列出指定目录下的文件和文件夹",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "目录路径，例如 /home/user/projects 或 C:/Users/user"
                    }
                },
                "required": ["path"]
            }
        ),
        types.Tool(
            name="read_file",
            description="读取指定文件的内容",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "文件路径，例如 /home/user/README.md"
                    }
                },
                "required": ["path"]
            }
        ),
        types.Tool(
            name="write_file",
            description="将内容写入指定文件（不存在则创建，存在则覆盖）",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "文件路径"
                    },
                    "content": {
                        "type": "string",
                        "description": "要写入文件的文本内容"
                    }
                },
                "required": ["path", "content"]
            }
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    """
    处理工具调用请求。
    当 AI 决定调用某个工具时，SDK 将 name 和 arguments 传入此函数。
    返回 TextContent 列表作为工具执行结果，AI 会将其整合到回复中。
    """

    if name == "list_directory":
        path = Path(arguments["path"])

        # 验证路径是否是有效目录
        if not path.is_dir():
            return [types.TextContent(
                type="text",
                text=f"错误：{path} 不是有效目录（路径不存在或不是目录）"
            )]

        # 遍历目录，区分文件和子目录
        items = [
            f"{'[目录]' if p.is_dir() else '[文件]'} {p.name}"
            for p in sorted(path.iterdir())  # sorted 使结果更整洁
        ]

        result = "\n".join(items) if items else "目录为空"
        return [types.TextContent(type="text", text=result)]

    elif name == "read_file":
        path = Path(arguments["path"])

        # 验证路径是否是有效文件
        if not path.is_file():
            return [types.TextContent(
                type="text",
                text=f"错误：{path} 不存在或不是文件"
            )]

        # 读取文件内容，强制使用 UTF-8 编码
        content = path.read_text(encoding="utf-8")
        return [types.TextContent(type="text", text=content)]

    elif name == "write_file":
        path = Path(arguments["path"])

        # 自动创建不存在的父目录（等价于 mkdir -p）
        path.parent.mkdir(parents=True, exist_ok=True)

        # 写入内容，强制使用 UTF-8 编码
        path.write_text(arguments["content"], encoding="utf-8")
        return [types.TextContent(
            type="text",
            text=f"已成功写入 {path}（{len(arguments['content'])} 个字符）"
        )]

    else:
        # 处理未知工具名称（正常情况下不应出现）
        return [types.TextContent(
            type="text",
            text=f"未知工具：{name}。可用工具：list_directory, read_file, write_file"
        )]


async def main():
    """
    通过 stdio 启动 MCP Server。
    stdio_server() 管理标准输入/输出的上下文，
    app.run() 进入事件循环处理来自 Client 的请求。
    """
    async with stdio_server() as streams:
        await app.run(*streams, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
